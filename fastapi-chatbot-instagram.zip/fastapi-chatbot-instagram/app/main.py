
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from pathlib import Path
import urllib.parse
import os

from .utils import generate_share_image, ensure_uploads_dir

BASE_DIR = Path(__file__).resolve().parent.parent
uploads_path = BASE_DIR / "static" / "uploads"
ensure_uploads_dir(uploads_path)

app = FastAPI(title="Chatbot + Instagram Share (Manual Flow)")

# Static & templates
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# CORS (relax for local dev; tighten in prod)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----- Models -----
class ChatMessage(BaseModel):
    message: str

class EndConversationPayload(BaseModel):
    caption: str
    image_text: str | None = None
    brand: str | None = "YourBrand"

# ----- Routes -----
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    # Demo chat page
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/api/message")
async def chat_message(payload: ChatMessage):
    # Simple echo/keyword responder for demo purposes
    msg = payload.message.strip().lower()
    if "price" in msg:
        reply = "Our pricing starts at $9.99/month."
    elif "hello" in msg or "hi" in msg:
        reply = "Hello! How can I help you today?"
    else:
        reply = f"You said: {payload.message}"
    return {"reply": reply}

@app.post("/api/end")
async def end_conversation(payload: EndConversationPayload):
    # Create a shareable image
    text = payload.image_text or "Thanks for chatting with us!"
    filename = generate_share_image(text=text, brand=payload.brand, out_dir=uploads_path)

    # Build a share URL that renders a helper page attempting Web Share API and offering fallbacks
    q = {
        "file": filename,
        "caption": payload.caption
    }
    share_url = f"/share?{urllib.parse.urlencode(q)}"
    return {"share_url": share_url, "static_image_url": f"/static/uploads/{filename}"}

@app.get("/share", response_class=HTMLResponse)
async def share(request: Request, file: str, caption: str = ""):
    # Validates file exists under uploads dir
    safe_name = os.path.basename(file)
    file_path = uploads_path / safe_name
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    image_url = f"/static/uploads/{safe_name}"
    return templates.TemplateResponse("end.html", {
        "request": request,
        "image_url": image_url,
        "caption": caption
    })
