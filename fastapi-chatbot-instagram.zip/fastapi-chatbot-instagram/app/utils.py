
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime
from pathlib import Path
import textwrap, os

def ensure_uploads_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)

def generate_share_image(text: str, brand: str | None, out_dir: Path) -> str:
    """Create a simple branded PNG social card and return filename."""
    ensure_uploads_dir(out_dir)

    width, height = 1080, 1080  # Instagram square
    bg = (245, 246, 250)        # light neutral background
    fg = (20, 20, 20)           # dark text
    accent = (0, 122, 255)      # subtle accent

    img = Image.new("RGB", (width, height), bg)
    draw = ImageDraw.Draw(img)

    # Load default fonts (system independent fallback)
    try:
        font_title = ImageFont.truetype("arial.ttf", 64)
        font_body = ImageFont.truetype("arial.ttf", 44)
        font_brand = ImageFont.truetype("arial.ttf", 40)
    except:
        font_title = ImageFont.load_default()
        font_body = ImageFont.load_default()
        font_brand = ImageFont.load_default()

    # Title
    title = "Thanks for chatting!"
    tw, th = draw.textsize(title, font=font_title)
    draw.text(((width - tw) / 2, 140), title, fill=fg, font=font_title)

    # Body (wrapped)
    body = text.strip()
    wrapped = textwrap.fill(body, width=24)
    draw.multiline_text((120, 300), wrapped, fill=fg, font=font_body, spacing=10)

    # Footer brand
    brand_text = f"— {brand}" if brand else ""
    bw, bh = draw.textsize(brand_text, font=font_brand)
    draw.text((width - bw - 60, height - bh - 80), brand_text, fill=accent, font=font_brand)

    # Timestamp small
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    draw.text((60, height - 80), ts, fill=(100,100,100))

    # Save
    fname = f"share_{int(datetime.now().timestamp())}.png"
    out_path = out_dir / fname
    img.save(out_path, format="PNG", optimize=True)
    return fname
