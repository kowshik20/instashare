
# Chatbot + Instagram Share (FastAPI, Python)

This is a minimal, end‑to‑end example showing how to:
- Build a simple chatbot API with FastAPI
- On "End conversation", generate a branded image
- Open a Share page that tries the Web Share API (mobile) to share to Instagram
- Provide fallbacks: download image, copy caption, open Instagram app/web

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000 in your browser.

## Notes

- Instagram blocks automatic caption prefill from third-party share flows. Users should copy/paste the caption if it doesn't carry over.
- The Web Share API with files works best on mobile browsers. Desktop browsers may not support file sharing; use the fallback buttons.
- This example does **not** auto-publish to Instagram (that requires the Instagram Graph API and a Professional account).

## Project layout

```
app/
  main.py           # FastAPI app with endpoints
  utils.py          # Image generator helper
templates/
  index.html        # Demo chat UI
  end.html          # Share helper page
static/
  styles.css        # Minimal styling
  uploads/          # Generated images are saved here
requirements.txt
README.md
```
